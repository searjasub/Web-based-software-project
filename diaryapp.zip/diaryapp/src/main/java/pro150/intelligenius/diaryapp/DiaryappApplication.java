package pro150.intelligenius.diaryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiaryappApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiaryappApplication.class, args);
	}

}
